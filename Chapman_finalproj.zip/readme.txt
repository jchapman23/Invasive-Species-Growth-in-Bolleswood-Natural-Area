DATA
For the final project, I use three different Excel files, each holding data for a different
plant 'type', and each holding data on plants within 890 plots in the Bolleswood Natural Area.
The Arbo datasets were provided by Chad Jones of the ES department.
These excel files track three types: herbs (grass cover), shrubs and vines, and trees.
Each of these files has data that shows the plot number, plant species name, and size for 7
intervals for the every 10 years from 1952-2012. Each file has 6671 (herbs), 7317(shrubs), 
and 9097(trees) instances in each file, for a total of 23085 total plants, *7 decades of
size recordings, where not every plant exists for all 7 decades (obviously).

STRATEGY
Over the past summer, I undertook a research project to break down this dataset through basic
shape/center and other statistics. This was meant to end with implementation of a machine
learning method, but did not as time did not allow. The goal of this research was to determine
what plot compositions (what collection of plants within a plot) would be found alongside
high-performing invasive plants. One such plant was 'Celastrus orbiculatus', a vine that
has been in the Arbo for all 7 decades recorded, and is the plant input in my code. The goal
was to use machine learning methods to classify plots as either 'high performing for 
Celastrus' or not, and be able to predict plant future high performing plots based on their
plot composition.
To do this I chose to implement a Random Forest and K-Means clustering w/PCA.
For both methods, I created a dataset that is a list lists. The greater list represents the
plots which have Celastrus in them (all 7 decades combined). Each plot has a corresponding
list of integers, which is the total for each species known to exist in the arbo; these are
not taken from the given year in which celastrus occurs, but rather the year befor it occurs.
This is done to produce a predictive model, using the prior years plot composition compared
to the size of the Celastrus plant in the current year to determine what composition is 
assossciated with what size.
In the Random Forest, this data is taken in, and the number of features is taken to be the
number of species in the Arbo. Selecting m of these features, I use the sklearn Random Forest
library to create and test random forests through all possible m's to determine the best.
In KMeans with PCA, I reduce the feature space of 254 features using a PCA method found online
to 2 primary components. I then perform KMeans on these components, validating with the
Silhouette test from the sklearn library to determine the best fit.

FINDINGS
Using the Random Forest Model, I found that even through using PCA, I was unable to get an
accuracy greater than around 83%. I believe this to be due to the very large feature space,
of which many of the features are meaningless (many plants do not occur near to celastrus 
due to environment). However, this is a prediction we can provide! To test, I would (and will
for presentation) implement a loop that would test 2012's celastrus plots against the
model built, and returns which plots are predicted to be of size 'A' or not. The code can
easily be altered to check other invasive species, and to check other size classes if the max size
is different for other species.

Using KMeans ww/PCA, I found that I was unable to produce clusters that broke down the set
by plot size. The process of creating principal components from the 255 elements seemed to be
too complex to capture in few enough components to graph clusters. The method I created has
commented out features to create the elbow graph, where the elbow appears to be between 4 and 7.
With these clusters still, it is not abnle to distinguish plot sizes from one another.
Interestingly, the data 