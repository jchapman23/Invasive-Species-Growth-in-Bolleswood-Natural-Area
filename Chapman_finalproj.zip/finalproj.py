#Josh Chapman
#11/30/2021
#COM307 Machine Learning/Data Mining
#Final Project

#This is a program to break down three excel files into operable data structures,
#and put this data through machine learning methods in the interest of
#predicting the growth of invasive species

#The two methods implemented  are Naive Bayes and K-Means clustering with PCA


import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score
from sklearn.cluster import KMeans
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier

structureH = []
structureS = []
structureT = []
trees = []
shrubs = []
herbs = []
curyear = []
part = []

# Assign spreadsheet filename to `file#`
file1 = 'exampleH.xlsx'
file2 = 'exampleS.xlsx'
file3 = 'exampleT.xlsx'
file4 = 'species.xlsx'

# Load spreadsheet
xl1 = pd.ExcelFile(file1)
xl2 = pd.ExcelFile(file2)
xl3 = pd.ExcelFile(file3)
xl4 = pd.ExcelFile(file4)

# Load a sheet into a DataFrame by name: df#
df1 = xl1.parse('Sheet1')
df2 = xl2.parse('Sheet1')
df3 = xl3.parse('Sheet1')
df4 = xl4.parse('Sheet1')

#load species lists by refrencing the column header in the excel sheet
herbtemp = df4[df4["Type"] == 'Herb']
shrubtemp = df4[df4["Type"] == 'Shrub']
treetemp = df4[df4["Type"] == 'Tree']

#convert the species lists to iterable nodes be tallied in methods for different analyses
for i in range(0,len(herbtemp.index)):
    pear = [herbtemp.iloc[i,0], 0]
    herbs.append(pear)

for i in range(0,len(shrubtemp.index)):
    pear = [shrubtemp.iloc[i,0], 0]
    shrubs.append(pear)

for i in range(0,len(treetemp.index)):
    pear = [treetemp.iloc[i,0], 0]
    trees.append(pear)

#this is not efficient, and I did not review this process of extraction since using it Summer '21

#pull data from the excel files, place into 2D (/4D) arrays
#arrays referenced to as structure[w][x][y][z]
#w is the plot number
#x is the year
#y accesses the plants within the specified plot and year
#z allows access to the data stored for each plant
for k in range(0,890):

    samp = df1[df1["Plot"] == k+1]

    if len(samp.index) > 0:
        for j in range(0,7):
            for i in range(0,len(samp.index)):
                col = j + 2
                if samp.iloc[i, col] == 'x':
                    duh = [k+1, samp.iloc[i, 1], samp.iloc[i, col]]
                    curyear.append(duh)
                elif not(math.isnan(samp.iloc[i, col])):
                    duh = [k+1, samp.iloc[i, 1], samp.iloc[i, col]]
                    curyear.append(duh)
            if len(curyear) >= 0:
                part.append(curyear)
                curyear = []
        if len(part) >= 0:
                structureH.append(part)
                part = []
    elif len(samp.index) == 0:
        part = []
        structureH.append(part)

for k in range(0,890):

    samp = df2[df2["Plot"] == k+1]

    if len(samp.index) > 0:
        for j in range(0,7):
            for i in range(0,len(samp.index)):
                col = j + 2
                if isinstance(samp.iloc[i, col], str):
                    if col > 4:
                        if not(math.isnan(samp.iloc[i, col + 4])):
                            duh = [k+1, samp.iloc[i, 1], samp.iloc[i, col], samp.iloc[i, col + 4]]
                            curyear.append(duh)
                        else:
                            duh = [k+1, samp.iloc[i, 1], samp.iloc[i, col]]
                            curyear.append(duh)
                    else:
                            duh = [k+1, samp.iloc[i, 1], samp.iloc[i, col]]
                            curyear.append(duh)
            if len(curyear) >= 0:
                part.append(curyear)
                curyear = []
        if len(part) >= 0:
                structureS.append(part)
                part = []
    elif len(samp.index) == 0:
        part = []
        structureS.append(part)

for k in range(0,890):

    samp = df3[df3["Plot"] == k+1]

    if len(samp.index) > 0:
        for j in range(0,7):
            for i in range(0,len(samp.index)):
                col = j + 2
                if not(math.isnan(samp.iloc[i, col])):
                    duh = [k+1, samp.iloc[i, 1], samp.iloc[i, col]]
                    curyear.append(duh)
                elif type(samp.iloc[i, col+7]) == str:
                    duh = [k+1, samp.iloc[i, 1], samp.iloc[i, col+7]]
                    curyear.append(duh)
            if len(curyear) >= 0:
                part.append(curyear)
                curyear = []
        if len(part) >= 0:
                structureT.append(part)
                part = []
    elif len(samp.index) == 0:
        part = []
        structureT.append(part)

########################################################################
#Code since beginning of final project

#Goes year by year to get the plot numbers of plots within that year that have the invasive species in it
#returns a list[x][y] where x holds the decade splits and y holds the plots within each decade
#Only uses the shrubs dataset because all invasive species are classified as shrubs
def invasivePlots(species):
    inva = []
    for j in range(0,7):
        yearplots = []
        for i in range(0,889):
            if len(structureS[i]) > 0:
                for k in range(0, len(structureS[i][j])):
                    if structureS[i][j][k][1] == species:
                        yearplots.append(i)
        inva.append(yearplots)
    return inva

#get_inv_size
#loops through the inva list created above, checking with the shrubs dataset to form a list
#of the size classes for each plot, which serves as a target dataset

#get_inv_size_K is for KMeans, and uses all available size classes to create a target
#dataset
def get_inv_size_K(years, species):
    big = []
    for i in range(1, len(years)):
        for j in range (0, len(years[i])):
            plot = years[i][j]
            for k in range(0, len(structureS[plot][i])):
                if structureS[plot][i][k][1] == species:
                    if structureS[plot][i][k][2] == 'A':
                        temp = 'A'
                    elif structureS[plot][i][k][2] == 'B':
                        temp = 'B'
                    elif structureS[plot][i][k][2] == 'V':
                        temp = 'V'
                    else:
                        temp = 'C'
            big.append(temp)
    return big

#get_inv_size_R is for the Random Forest, and creates a binary for the
#target dataset
def get_inv_size_R(years, species):
    big = []
    for i in range(1, len(years)):
        for j in range (0, len(years[i])):
            plot = years[i][j]
            for k in range(0, len(structureS[plot][i])):
                if structureS[plot][i][k][1] == species:
                    if structureS[plot][i][k][2] == 'A':
                        temp = 1
                    else:
                        temp = 0
            big.append(temp)
    return big

#uses the inva list created above to build a list composed of the plots in inva,
#and all the plants they contain (and those plants info, such as name and size).
#This combines the herbs shrubs and trees into a single plot as well
def plot_build(years):
    big = []
    for i in range(1, len(years)):
        for j in range (0, len(years[i])):
            plot = years[i][j]
            one = structureH[plot][i-1]
            two = structureS[plot][i-1]
            if len(structureT[plot]) > 0:
                three = structureT[plot][i-1]
            else:
                three = []
            big.append(one + two + three)
    return big

#uses the list created in plot_build to total up the species within each plot, creating
#255 features for each plot, each feature a number representing total number of this species
#in that plot
def species_plots(list):
    big = []
    for i in range(0, len(list)):
        templist = []
        for j in range(0, len(df4)):
            temptotal = 0
            for k in range(0, len(list[i])):
                if df4.iloc[j][0] == list[i][k][1]:
                    temptotal+=1
            templist.append(temptotal)
        big.append(templist)
    return big

#PCA method found online, takes in data dataset and the desired number of PC's
#returns a list that represents X as those components
def PCA(X , num_components):
     
    X_meaned = X - np.mean(X , axis = 0)
    cov_mat = np.cov(X_meaned , rowvar = False)
    eigen_values , eigen_vectors = np.linalg.eigh(cov_mat)
    sorted_index = np.argsort(eigen_values)[::-1]
    sorted_eigenvalue = eigen_values[sorted_index]
    sorted_eigenvectors = eigen_vectors[:,sorted_index]
    eigenvector_subset = sorted_eigenvectors[:,0:num_components]
    X_reduced = np.dot(eigenvector_subset.transpose() , X_meaned.transpose() ).transpose()
    return X_reduced

#method to implement the random forest from the sklearn library and create results
#established methods are used at the start to process the dataset and form the needed
#arrays
#Validation is done through KFold cross-validation, where a training set is chosen by
#creating 5 folds (leaving out about a year of data, since we will have 6 decades)
def run_forest():
    spec = 'Celastrus orbiculatus'
    invP = invasivePlots(spec)
    sz = get_inv_size_R(invP, spec)
    l = plot_build(invP)
    these = species_plots(l)

    sizes = np.array(sz)
    this = np.array(these)
    kf = KFold(5)
    
    for train_index, test_index in kf.split(this):
        this_train, this_test = this[train_index], this[test_index]
        sizes_train, sizes_test = sizes[train_index], sizes[test_index]
    
    for n in range(1, 255):
        rf = RandomForestClassifier(n_estimators=n, min_samples_split=10)
        rf.fit(this_train, sizes_train)
        print(rf.score(this_test, sizes_test), n)

#method to implement the KMeans package from sklearn
#uses established methods to preprocess
#also uses PCA method to reduce feature space to 2 features
#Currently the plot that is shown is colored based on size class, not any prediction
#second block commented out performs the elbow test and produces a graph
#third block does PCA, and prints a graph with the clusters
def run_kmeans():
    spec = 'Celastrus orbiculatus'
    invP = invasivePlots(spec)
    sz = get_inv_size_K(invP, spec)
    l = plot_build(invP)
    these = species_plots(l)

    sizes = np.array(sz)
    this = np.array(these)
    kf = KFold(5)

    mat_reduced = PCA(this, 2)
    for train_index, test_index in kf.split(mat_reduced):
        this_train, this_test = mat_reduced[train_index], mat_reduced[test_index]
        sizes_train, sizes_test = sizes[train_index], sizes[test_index]

    PCframe = pd.DataFrame(this_train, columns=['PC1', 'PC2'])
    PCframe['sizes'] = sizes_train

    PCtest = pd.DataFrame(this_test, columns=['PC1', 'PC2'])
    PCtest['sizes'] = sizes_test

    #comment out for other plots
    plt.figure(figsize=(10,10))
    sns.scatterplot(data=PCframe, x='PC1', y='PC2', hue='sizes', s=60)
    plt.show()

    x = PCframe.iloc[:, 0:2]
    y = PCtest.iloc[:, 0:2]
    
    #comment out for other plots
    #wcss = []
    #for i in range(1, 25):
    #    kmeans = KMeans(i)
    #    kmeans.fit(x)
    #    wcss_iter = kmeans.inertia_
    #    wcss.append(wcss_iter)
    #num_clusters = range(1, 25)
    #plt.plot(num_clusters, wcss)
    #plt.title('Elbow')
    #plt.ylabel('WCSS')
    #plt.show()

    #comment out for other plots
    #kmeans = KMeans(4)
    #kmeans.fit(x)
    #score = accuracy_score(sizes_test, kmeans.predict(y))
    #asdf = kmeans.predict(y)
    #for i in range(0, len(sizes_test)):
    #    print(sizes_test[i], asdf[i])
    #print(kmeans.predict(x))
    #print(kmeans.labels_)
    #print(y)
    #identified_clusters = kmeans.labels_
    #data_with_clusters = PCframe.copy()
    #data_with_clusters['Clusters'] = identified_clusters
    #plt.scatter(data_with_clusters['PC1'],data_with_clusters['PC2'],c=data_with_clusters['Clusters'],cmap='rainbow')
    #plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], color='black')
    #plt.show()

def main():
    run_forest()
main()
